const home = document.querySelector('.home label');
        const container2 = document.querySelector('.container2');

        function clickedhome(){
            if (home.className == "fa fa-home")
                home.className = "fa fa-times";

            else
                home.className = "fa fa-home"
        }


        const bell = document.querySelector('.bell label');
        const container = document.querySelector('.container');

        function clicked(){
            if (bell.className == "fa fa-bell")
                bell.className = "fa fa-times";

            else
                bell.className = "fa fa-bell"
        }

        const msg = document.querySelector('.msg label');
        const container1 = document.querySelector('.container1');

        function clickedmsg(){
            if (msg.className == "fa fa-envelope")
                msg.className = "fa fa-times";

            else
                msg.className = "fa fa-envelope"
        }